<?php

/*
    Plugin Name: Auto Sitemap Ping
    Plugin URI: https://almajd1.com
    Plugin Description: Automatically ping search engines whenever the sitemap.xml file is updated.
    Plugin Version: 1.0
    Plugin Date: 2022-04-10
    Plugin Author: Your Name Here
    Plugin Author URI: https://almajd1.com
    Plugin License: GPLv3
    Plugin Minimum Question2Answer Version: 1.8
    Plugin Update Check URI: https://almajd1.com/auto_sitemap_ping/version.txt
*/

if (!defined('QA_VERSION')) {
    header('Location: ../../');
    exit;
}

qa_register_plugin_module('page', 'sitemap-ping-page.php', 'sitemap_ping_page', 'Sitemap Ping Page');

qa_register_plugin_phrases('lang/sitemap-ping-lang-*.php', 'sitemap_ping');

