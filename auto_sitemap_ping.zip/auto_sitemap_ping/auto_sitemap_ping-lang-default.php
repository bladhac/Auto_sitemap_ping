<?php

return array(
    'sitemap_ping_button' => 'Sitemap Ping'
);

