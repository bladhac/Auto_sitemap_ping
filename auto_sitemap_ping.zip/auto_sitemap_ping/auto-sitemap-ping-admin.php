<?php

class auto_sitemap_ping_admin
{
    private $directory;
    private $urltoroot;

    function load_module($directory, $urltoroot)
    {
        $this->directory = $directory;
        $this->urltoroot = $urltoroot;

        if (qa_clicked('auto_sitemap_ping_save_button')) {
            $notification_interval = (int)qa_post_text('auto_sitemap_ping_notification_interval');
            qa_opt('auto_sitemap_ping_notification_interval', $notification_interval);
            qa_redirect(qa_request(), array('auto_sitemap_ping_save' => 1));
        }
    }

    function admin_form()
    {
        $saved = qa_clicked('auto_sitemap_ping_save_button');
        $interval = qa_opt('auto_sitemap_ping_notification_interval', 24);

        $fields = array(
            array(
                'label' => qa_lang('sitemap_ping/sitemap_ping_settings'),
                'type' => 'static',
            ),
            array(
                'label' => qa_lang('sitemap_ping/sitemap_ping_note'),
                'type' => 'static',
            ),
            array(
                'id' => 'auto_sitemap_ping_notification_interval',
                'label' => qa_lang('sitemap_ping/notification_interval'),
                'value' => $interval,
                'tags' => 'NAME="auto_sitemap_ping_notification_interval"',
                'type' => 'number',
                'suffix' => ' ' . qa_lang_html('sitemap_ping/notification_interval_note') . ' ' . qa_lang_html('sitemap_ping/notification_interval_note2'),
                'error' => qa_lang_html('sitemap_ping/notification_interval_error'),
            ),
            array(
                'type' => 'blank',
            ),
            array(
                'id' => 'auto_sitemap_ping_save_button',
                'label' => qa_lang('main/save_button'),
                'tags' => 'NAME="auto_sitemap_ping_save_button"',
                'type' => 'button',
            ),
        );

        return array(
            'ok' => $saved ? qa_lang_html('sitemap_ping/notification_interval_saved') : null,

            'fields' => $fields,

            'buttons' => array(),
        );
    }
}

