<?php

class qa_html_theme_layer extends qa_html_theme_base
{
    function footer()
    {
        qa_html_theme_base::footer();
        $this->output('<div class="qa-auto-sitemap-ping-button">');
        $this->output('<a href="' . qa_path_html('sitemap-ping') . '">' . qa_lang('auto_sitemap_ping_lang/sitemap_ping_button') . '</a>');
        $this->output('</div>');
    }
}

