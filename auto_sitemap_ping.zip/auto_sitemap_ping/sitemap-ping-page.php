<?php

class sitemap_ping_page
{
    function match_request($request)
    {
        $parts = explode('/', $request);

        return $parts[0] === 'sitemap-ping';
    }

    function process_request($request)
    {
        require_once QA_INCLUDE_DIR . 'app/updates.php';

        if (qa_using_external_sitemap() && qa_opt('sitemap_enabled')) {
            $sitemap_url = qa_opt('site_url') . 'sitemap.xml';
            $search_engines = array(
                'Google' => 'http://www.google.com/webmasters/sitemaps/ping?sitemap=',
                'Bing' => 'http://www.bing.com/webmaster/ping.aspx?siteMap=',
            );

            $result = '';

            foreach ($search_engines as $name => $url) {
                $ping_url = $url . urlencode($sitemap_url);
                $ch = curl_init($ping_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);

                $result .= sprintf('%s (%d): %s', $name, $http_code, $response);
            }

            header('Content-Type: text/plain');
            echo $result;
            exit;
        }

        header('HTTP/1.0 404 Not Found');
        header('Content-Type: text/plain');
        echo 'Not Found';
        exit;
    }
}
