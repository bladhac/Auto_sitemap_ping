<?php

function auto_sitemap_ping() {
    $url = 'https://example.com/sitemap.xml';
    $pingUrl = 'http://www.google.com/webmasters/sitemaps/ping?sitemap=' . urlencode($url);
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $pingUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($ch);
    curl_close($ch);
}

qa_register_plugin_module('event', 'auto_sitemap_ping.php', 'auto_sitemap_ping', 'Auto Sitemap Ping');
