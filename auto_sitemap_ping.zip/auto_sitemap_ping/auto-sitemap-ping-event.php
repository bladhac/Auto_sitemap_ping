<?php
class auto_sitemap_ping_event
{
    function process_event($event, $userid, $handle, $cookieid, $params)
    {
        if ($event === 'q2a_sitemap_written') {
            $sitemap_path = qa_opt('site_url') . 'sitemap.xml';
            $search_engines = array(
                'Google' => 'http://www.google.com/webmasters/sitemaps/ping?sitemap=',
                'Bing' => 'http://www.bing.com/webmaster/ping.aspx?siteMap=',
            );

            foreach ($search_engines as $name => $url) {
                $ping_url = $url . urlencode($sitemap_path);
                $ch = curl_init($ping_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_exec($ch);
                curl_close($ch);
            }
        }
    }
}
