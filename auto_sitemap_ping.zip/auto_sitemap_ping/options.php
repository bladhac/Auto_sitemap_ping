<?php

class auto_sitemap_ping_options
{
    private $directory;
    private $urltoroot;

    function load_module($directory, $urltoroot)
    {
        $this->directory = $directory;
        $this->urltoroot = $urltoroot;

        qa_register_plugin_module('module', 'auto-sitemap-ping-admin.php', 'auto_sitemap_ping_admin', 'Auto Sitemap Ping Admin');
    }

    function suggest_requests()
    {
        return array(
            array(
                'title' => 'Auto Sitemap Ping Settings',
                'request' => 'auto-sitemap-ping-settings',
                'nav' => 'M',
            ),
        );
    }
}

